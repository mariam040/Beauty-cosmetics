const Product = require('../models/product');
const multer = require("multer");
const path = require("path");

// setting to store in multer
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "public/images"); // images stored here
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname)); // unique name
  },
});
const upload = multer({ storage: storage });

// API for Bring all products
const getAllProducts = async (req, res) => {
  try {
    const products = await Product.find();
    res.json(products);
  } catch (error) {
    res.status(500).json({ message: 'An error occurred while fetching the products.', error });
  }
};

// Add new product
const addProduct = async (req, res) => {
  try {
    const { name, category, quantity, price, description } = req.body;
    const image = req.file ? req.file.filename : null;

    const product = new Product({
      name,
      category,
      quantity,
      price,
      description,
      image,
    });

    await product.save();
    res.status(201).json(product);
  } catch (error) {
    res.status(400).json({ message: 'Failed to add product', error });
  }
};

// Show the shop page
const renderShopPage = async (req, res) => {
  try {
    const products = await Product.find();
    res.render('shop', { products });
  } catch (error) {
    console.error(error);
    res.status(500).send('An error occurred while loading the page.');
  }
};


// Show product details page
const renderProductDetails = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) return res.status(404).send('Product not found');

    res.render('product-details', { product });
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
};

// Search products using AJAX
const searchProductsAjax = async (req, res) => {
  try {
    const query = req.query.q;
    console.log('🔍 Search Query:', query); // أهو اللوج هنا
    const products = await Product.find({
      name: { $regex: query, $options: 'i' }
    });
    res.json(products);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Something went wrong' });
  }
};




// Export all functions and upload
module.exports = {
  upload,
  getAllProducts,
  addProduct,
  renderShopPage,
  renderProductDetails,
  searchProductsAjax
};
