const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const path = require('path');

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

// EJS settings
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Static files
app.use(express.static('public'));
app.use('/images', express.static(path.join(__dirname, 'public/images')));

// MongoDB connection
mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log('✅ MongoDB connected'))
  .catch(err => console.error('❌ MongoDB error:', err));

// Controllers
const { renderShopPage, renderProductDetails } = require('./controllers/productController');

// Render routes (frontend pages)
app.get('/shop', renderShopPage);
app.get('/product/:id', renderProductDetails);

// ✅ Checkout page
app.get('/checkout', (req, res) => {
  res.render('checkout'); // لازم يكون فيه views/checkout.ejs
});

// Admin page (اختياري)
app.get('/admin', (req, res) => res.render('admin'));

// API routes
const productApiRoutes = require('./routes/productApiRoutes');
app.use('/api/products', productApiRoutes);

// Start server
app.listen(port, () => {
  console.log(`🚀 Server running on http://localhost:${port}`);
});
