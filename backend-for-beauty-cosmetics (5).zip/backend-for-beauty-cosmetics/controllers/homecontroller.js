const Product = require('../models/product');
const multer = require("multer");
const path = require("path");

exports.renderHomepage = async (req, res) => {
  try {
    const products = await Product.find().limit(7);
    res.render('homepage', { products }); // ✅ products is passed to EJS
  } catch (error) {
    console.error('Error fetching products:', error);
    res.status(500).send('Server Error');
  }
};

