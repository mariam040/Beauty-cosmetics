const Product = require('../models/product');

// ✅ GET: Show Cart Page
exports.getCart = (req, res) => {
  const cartItems = req.session.cart || [];

  const shipping = 50; // constant value
  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const discount = 0;
  const total = subtotal + shipping - discount;

  res.render('shoppingCart', {
    cartItems,
    subtotal,
    discount,
    shipping,  // ✅ make sure this is included
    total
  });
};




// ✅ ADD to Cart (session-based)
exports.addToCart = async (req, res) => {
  const productId = req.params.id;
  const product = await Product.findById(productId);

  if (!product) return res.status(404).send('Product not found');

  if (!req.session.cart) req.session.cart = [];

  const existing = req.session.cart.find(item => item._id == product._id);

  if (existing) {
    existing.quantity += 1;
  } else {
    req.session.cart.push({
      _id: product._id,
      name: product.name,
      price: product.price,
      image: product.image, // only if you use it
      quantity: 1
    });
  }

  res.redirect('/shoppingCart');
};

// ✅ REMOVE from Cart
exports.removeFromCart = (req, res) => {
  const id = req.params.id;
  if (!req.session.cart) return res.redirect('/shoppingCart');

  req.session.cart = req.session.cart.filter(item => item._id !== id);
  res.redirect('/shoppingCart');
};

// ✅ UPDATE Quantity
exports.updateQuantity = (req, res) => {
  const { id } = req.params;
  const { quantity } = req.body;

  const cart = req.session.cart || [];

  const item = cart.find(item => item._id === id);
  if (item) {
    const newQty = parseInt(quantity);
    if (!Number.isInteger(newQty) || newQty < 1) {
      return res.status(400).send('Invalid quantity');
    }
    item.quantity = newQty;
  }

  res.redirect('/shoppingCart');
};
