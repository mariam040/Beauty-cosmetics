const jwt = require('jsonwebtoken');
const User = require('../model/user');
const asyncHandler = require('express-async-handler');

// @desc    Authenticate admin
// @route   POST /api/auth/login
// @access  Public
const loginAdmin = asyncHandler(async (req, res) => {
  const { username, password } = req.body;

  const user = await User.findOne({ username, role: 'admin' });
  
  if (user && (await user.comparePassword(password))) {
    const token = jwt.sign(
      { id: user._id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '1d' }
    );
    
    res.json({
      _id: user._id,
      username: user.username,
      role: user.role,
      token
    });
  } else {
    res.status(401);
    throw new Error('Invalid credentials');
  }
});

// @desc    Logout admin (client-side operation)
// @route   POST /api/auth/logout
// @access  Private
const logoutAdmin = asyncHandler(async (req, res) => {
  res.json({ message: 'Logged out successfully' });
});

module.exports = {
  loginAdmin,
  logoutAdmin
};