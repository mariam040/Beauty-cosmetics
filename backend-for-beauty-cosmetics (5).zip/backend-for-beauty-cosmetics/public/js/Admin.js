let editingId = null;
let authToken = localStorage.getItem('adminToken');

document.addEventListener("DOMContentLoaded", function () {
    // Check if user is authenticated
    if (!authToken) {
        document.getElementById('loginOverlay').style.display = 'flex';
    } else {
        document.getElementById('loginOverlay').style.display = 'none';
        loadProducts();
    }
    
    document.getElementById('productTableSection').style.display = 'none';
    document.getElementById('deleteProductSection').style.display = 'none';
    document.getElementById('editProductSection').style.display = 'none';
    document.getElementById('productForm').style.display = 'none';
});

function login() {
    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();
    const error = document.getElementById("loginError");

    // Hardcoded admin credentials
    const validUsername = "admin";
    const validPassword = "admin123";

    if (username === validUsername && password === validPassword) {
        // Generate a fake token for localStorage
        const fakeToken = "admin-authenticated-" + Date.now();
        localStorage.setItem('adminToken', fakeToken);
        authToken = fakeToken;
        
        document.getElementById("loginOverlay").style.display = "none";
        loadProducts();
        error.textContent = "";
    } else {
        error.textContent = "Invalid username or password.";
    }
}

function loadProducts() {
    fetch('http://localhost:5000/api/products', {
        method: 'GET',
        headers: {
            'Authorization': `Bearer ${authToken}`,
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(products => {
        updateProductTable(products);
        updateDropdowns(products);
    })
    .catch(error => {
        console.error('Error loading products:', error);
    });
}

function updateProductTable(products) {
    const productItems = document.getElementById('productItems');
    productItems.innerHTML = '';

    if (products.length === 0) {
        productItems.innerHTML = '<tr><td colspan="7" style="text-align: center;">No products found</td></tr>';
        return;
    }

    products.forEach(product => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${product.name}</td>
            <td>
                ${product.image ? 
                    `<img src="http://localhost:5000/${product.image}" alt="Product Image" style="width: 50px; height: 50px; object-fit: cover;">` : 
                    'No Image'
                }
            </td>
            <td>${product.category}</td>
            <td>${product.quantity}</td>
            <td>$${product.price.toFixed(2)}</td>
            <td>${product.description}</td>
            <td>
                <button class="edit-btn" onclick="editProduct('${product._id}')">Edit</button>
                <button class="delete-btn" onclick="deleteProduct('${product._id}')">Delete</button>
            </td>
        `;
        productItems.appendChild(row);
    });
}

function updateDropdowns(products) {
    // Update edit dropdown
    const editDropdown = document.getElementById('productSelectForEdit');
    editDropdown.innerHTML = '<option value="">Select a product to edit</option>';
    
    // Update delete dropdown
    const deleteDropdown = document.getElementById('productSelectForDelete');
    deleteDropdown.innerHTML = '<option value="">Select a product to delete</option>';

    products.forEach(product => {
        const editOption = document.createElement('option');
        editOption.value = product._id;
        editOption.textContent = product.name;
        editDropdown.appendChild(editOption);

        const deleteOption = document.createElement('option');
        deleteOption.value = product._id;
        deleteOption.textContent = product.name;
        deleteDropdown.appendChild(deleteOption);
    });
}

function showAddProductForm() {
    document.getElementById('productForm').style.display = 'block';
    document.getElementById('editProductSection').style.display = 'none';
    document.getElementById('deleteProductSection').style.display = 'none';
    document.getElementById('formTitle').textContent = 'Add Product';
    editingId = null;
    clearForm();
}

function closeAddProductForm() {
    document.getElementById('productForm').style.display = 'none';
    clearForm();
}

function showEditProductForm() {
    document.getElementById('editProductSection').style.display = 'block';
    document.getElementById('productForm').style.display = 'none';
    document.getElementById('deleteProductSection').style.display = 'none';
}

function showDeleteProductForm() {
    document.getElementById('deleteProductSection').style.display = 'block';
    document.getElementById('productForm').style.display = 'none';
    document.getElementById('editProductSection').style.display = 'none';
}

function clearForm() {
    document.getElementById('productName').value = '';
    document.getElementById('productImage').value = '';
    document.getElementById('category').value = '';
    document.getElementById('quantity').value = '';
    document.getElementById('price').value = '';
    document.getElementById('description').value = '';
    document.getElementById('successMessage').style.display = 'none';
}

function saveProduct() {
    const formData = new FormData();
    
    formData.append('name', document.getElementById('productName').value);
    formData.append('category', document.getElementById('category').value);
    formData.append('quantity', document.getElementById('quantity').value);
    formData.append('price', document.getElementById('price').value);
    formData.append('description', document.getElementById('description').value);
    
    const imageFile = document.getElementById('productImage').files[0];
    if (imageFile) {
        formData.append('image', imageFile);
    }

    const url = editingId ? 
        `http://localhost:5000/api/products/${editingId}` : 
        'http://localhost:5000/api/products';
    const method = editingId ? 'PUT' : 'POST';

    fetch(url, {
        method: method,
        headers: {
            'Authorization': `Bearer ${authToken}`
        },
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data._id || data.name) { // Success response
            document.getElementById('successMessage').textContent = 
                editingId ? 'Product updated successfully' : 'Product added successfully';
            document.getElementById('successMessage').style.display = 'block';
            
            setTimeout(() => {
                closeAddProductForm();
                loadProducts(); // Reload products
            }, 1500);
        } else {
            alert('Error: ' + (data.message || 'Failed to save product'));
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error saving product');
    });
}

function editProduct(productId) {
    // Find product in current data or fetch from server
    fetch(`http://localhost:5000/api/products`, {
        method: 'GET',
        headers: {
            'Authorization': `Bearer ${authToken}`,
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(products => {
        const product = products.find(p => p._id === productId);
        if (product) {
            editingId = productId;
            
            document.getElementById('productForm').style.display = 'block';
            document.getElementById('editProductSection').style.display = 'none';
            document.getElementById('deleteProductSection').style.display = 'none';
            document.getElementById('formTitle').textContent = 'Edit Product';
            
            document.getElementById('productName').value = product.name;
            document.getElementById('category').value = product.category;
            document.getElementById('quantity').value = product.quantity;
            document.getElementById('price').value = product.price;
            document.getElementById('description').value = product.description;
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error loading product');
    });
}

function loadProductForEdit() {
    const productId = document.getElementById('productSelectForEdit').value;
    if (productId) {
        editProduct(productId);
    }
}

function deleteProduct(productId) {
    if (confirm('Are you sure you want to delete this product?')) {
        fetch(`http://localhost:5000/api/products/${productId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${authToken}`,
                'Content-Type': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.message) {
                alert('Product deleted successfully');
                loadProducts(); // Reload products
            } else {
                alert('Error: ' + (data.message || 'Failed to delete product'));
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error deleting product');
        });
    }
}

function deleteSelectedProduct() {
    const productId = document.getElementById('productSelectForDelete').value;
    if (productId) {
        deleteProduct(productId);
    }
}

function logout() {
    fetch('http://localhost:5000/api/auth/logout', {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${authToken}`,
            'Content-Type': 'application/json'
        }
    })
    .then(() => {
        localStorage.removeItem('adminToken');
        authToken = null;
        document.getElementById('loginOverlay').style.display = 'flex';
        document.getElementById('productItems').innerHTML = '';
    })
    .catch(error => {
        console.error('Error:', error);
        // Still logout locally even if server request fails
        localStorage.removeItem('adminToken');
        authToken = null;
        document.getElementById('loginOverlay').style.display = 'flex';
    });
}