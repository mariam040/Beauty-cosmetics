const express = require('express');
const router = express.Router();
const {
  getAllProducts,
  addProduct,
  upload,
  searchProductsAjax
} = require('../controllers/productController');

// API: Get all
router.get('/', getAllProducts);

// API: Add product
router.post('/', upload.single('image'), addProduct);

// API: Search
router.get('/search', searchProductsAjax);

module.exports = router;
router.get('/shop/perfume', async (req, res) => {
  try {
    const perfumeProducts = await Product.find({ category: 'perfume' });
    res.render('perfumeShop', { products: perfumeProducts });
  } catch (error) {
    console.error('Error fetching perfume products:', error);
    res.status(500).send('Server Error');
  }
});