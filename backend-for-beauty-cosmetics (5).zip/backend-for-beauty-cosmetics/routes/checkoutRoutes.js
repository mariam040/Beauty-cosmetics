const express = require('express');
const router = express.Router();
const cartController = require('../controllers/cartcontroller');
const Order = require('../models/Order');

// POST route to handle checkout form
router.post('/checkout', async (req, res) => {
  try {
    const {
      fullname, phone, city, area, address,
      floor, apartment, addressName, paymentMethod, cart, total
    } = req.body;

    if (!fullname || !phone || !address || !cart || !total) {
      return res.status(400).send('❌ Missing required fields.');
    }

    let parsedCart;
    try {
      parsedCart = JSON.parse(cart);
    } catch (err) {
      return res.status(400).send('❌ Invalid cart format.');
    }

    const newOrder = new Order({
      fullname, phone, city, area, address,
      floor, apartment, addressName, paymentMethod,
      cart: parsedCart, total
    });

    await newOrder.save();
    req.session.cart = []; // Clear cart after order

    res.redirect('/checkout-success');
  } catch (err) {
    console.error(err);
    res.status(500).send('❌ Error placing order.');
  }
});

// Render success page
router.get('/checkout-success', (req, res) => {
  res.render('checkout-success');
});

router.get('/add/:id', cartController.addToCart);


module.exports = router;
