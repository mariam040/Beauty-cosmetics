const express = require('express');
const router = express.Router();
const User = require('../models/User');

// GET auth page
router.get('/auth', (req, res) => {
  res.render('auth', { message: null });
});

// GET login page (optional if needed separately)
router.get('/login', (req, res) => {
  res.render('auth', { message: null });
});

// POST signup
router.post('/signup', async (req, res) => {
  const { name, email, password } = req.body;
  try {
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.send('Email already registered');
    }
    const newUser = new User({ name, email, password });
    await newUser.save();
    res.redirect('/login');
  } catch (err) {
    console.error(err);
    res.send('Signup failed');
  }
});


// ✅ FIXED: POST login route wrapped in async function
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ email, password });
    if (user) {
      req.session.user = user;
      res.redirect('/homepage');
    } else {
      res.send('Invalid credentials');
    }
  } catch (err) {
    console.error(err);
    res.send('Login failed');
  }
});


module.exports = router;
