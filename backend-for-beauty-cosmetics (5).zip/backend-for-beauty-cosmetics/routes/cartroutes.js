const express = require('express');
const router = express.Router();
const cartController = require('../controllers/cartcontroller');

router.post('/add/:id', cartController.addToCart);  // ✅ Add to session cart
router.get('/shoppingCart', cartController.getCart); // ✅ Show session cart
router.post('/remove/:id', cartController.removeFromCart);
router.post('/update/:id', cartController.updateQuantity);

module.exports = router;
