const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
  fullname: String,
  phone: String,
  city: String,
  area: String,
  address: String,
  floor: String,
  apartment: String,
  addressName: String,
  paymentMethod: String,
  cart: [
    {
      name: String,
      price: Number,
      quantity: Number
    }
  ],
  total: Number
}, { timestamps: true });

module.exports = mongoose.models.Order || mongoose.model('Order', orderSchema);
