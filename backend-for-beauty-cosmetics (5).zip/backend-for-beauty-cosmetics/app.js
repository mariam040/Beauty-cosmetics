const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const path = require('path');
const session = require('express-session');
const Order = require('./models/Order');

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;
const staticRoutes = require('./routes/staticRoutes'); // ✅ Fixed name here
const authRoutes = require('./routes/authRoutes');
// EJS settings
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: 'secretKey',
  resave: false,
  saveUninitialized: true
}));

// Static files
app.use(express.static('public'));
app.use('/images', express.static(path.join(__dirname, 'public/images')));
app.use('/', staticRoutes);

//auth files
app.get('/auth', (req, res) => {
  res.render('auth'); // assuming your file is views/auth.ejs
});

app.use(express.static('public'));
app.use('/', authRoutes);


// MongoDB connection
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/yourdbname')
  .then(() => console.log('✅ MongoDB connected'))
  .catch(err => console.error('❌ MongoDB error:', err));

// Controllers
const { renderShopPage, renderProductDetails } = require('./controllers/productController');
const { renderHomepage } = require('./controllers/homeController');
const { getCart } = require('./controllers/cartcontroller');

// Routes
const cartRoutes = require('./routes/cartroutes');
const checkoutRoutes = require('./routes/checkoutRoutes');
const productApiRoutes = require('./routes/productApiRoutes');

// Use Routes
app.use('/cart', cartRoutes);
app.use('/', checkoutRoutes);
app.use('/api/products', productApiRoutes);

// Page Routes
app.get('/homepage', renderHomepage);
app.get('/shop', renderShopPage);
app.get('/product/:id', renderProductDetails);
app.get('/shoppingCart', getCart);

app.get('/checkout', (req, res) => {
  const cartItems = req.session.cart || [];
  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const shipping = 50;
  const total = subtotal + shipping;
  res.render('checkout', { cartItems, subtotal, shipping, total });
});

app.get('/checkout-success', (req, res) => {
  res.render('checkout-success');
});

app.get('/aboutus', (req, res) => {
  res.render('aboutus');
});

// Category Pages
const Product = require('./models/product');

app.get('/perfume', async (req, res) => {
  try {
    const products = await Product.find({ category: 'perfume' });
    res.render('perfume', { products });
  } catch (err) {
    console.error(err);
    res.status(500).send('Error loading perfume products');
  }
});

app.get('/makeup', async (req, res) => {
  const products = await Product.find({ category: { $regex: /^makeup$/i } });
  res.render('makeup', { products });
});

app.get('/bodycare', async (req, res) => {
  const products = await Product.find({ category: { $regex: /^body$/i } });
  res.render('bodycare', { products });
});

app.get('/facecare', async (req, res) => {
  const products = await Product.find({ category: { $regex: /^face$/i } });
  res.render('facecare', { products });
});

// Admin
app.get('/admin', (req, res) => res.render('admin'));

app.get('/admin/user-details', async (req, res) => {
  try {
    const orders = await Order.find();
    res.render('userdetails', { orders });
  } catch (err) {
    console.error(err);
    res.status(500).send('Error fetching user details');
  }
});

// Start server
app.listen(port, () => {
  console.log(`🚀 Server running on http://localhost:${port}`);
});
